/*****************************************************************//**
 * @file main_vanilla_test.cpp
 *
 * @brief Basic test of 4 basic i/o cores
 *
 * @author p chu
 * @version v1.0: initial release
 *********************************************************************/

//#define _DEBUG

#include "chu_init.h"
#include "gpio_cores.h"
#include "sseg_core.h"
//#include "uart_core.h"
#include "ps2_core.h"
//#include "mic_core.h"
//#include <string>
#include <cmath>


/**
 * blink once per second for 5 times.
 * provide a sanity check for timer (based on SYS_CLK_FREQ)
 * @param led_p pointer to led instance
 */
void timer_check(GpoCore *led_p) {
   int i;

   for (i = 0; i < 5; i++) {
      led_p->write(0xffff);
      sleep_ms(500);
      led_p->write(0x0000);
      sleep_ms(500);
      debug("timer check - (loop #)/now: ", i, now_ms());
   }
}

/**
 * leds flash according to switch positions.
 * @param led_p pointer to led instance
 * @param sw_p pointer to switch instance
 */
void sw_check(GpoCore *led_p, GpiCore *sw_p) {
   int i, s;

   s = sw_p->read();
   for (i = 0; i < 30; i++) {
      led_p->write(s);
      sleep_ms(50);
      led_p->write(0);
      sleep_ms(50);
   }
}

/**
 * Test pattern in 7-segment LEDs
 * @param sseg_p pointer to 7-seg LED instance
 */

void sseg_check(SsegCore *sseg_p) {
   int i, n;
   uint8_t dp;

   //turn off led
   for (i = 0; i < 8; i++) {
      sseg_p->write_1ptn(0xff, i);
   }
   //turn off all decimal points
   sseg_p->set_dp(0x00);

   // display 0x0 to 0xf in 4 epochs
   // upper 4  digits mirror the lower 4
   for (n = 0; n < 4; n++) {
      for (i = 0; i < 4; i++) {
         sseg_p->write_1ptn(sseg_p->h2s(i + n * 4), 3 - i);
         sseg_p->write_1ptn(sseg_p->h2s(i + n * 4), 7 - i);
         sleep_ms(300);
      } // for i
   }  // for n
      // shift a decimal point 4 times
   for (i = 0; i < 4; i++) {
      bit_set(dp, 3 - i);
      sseg_p->set_dp(1 << (3 - i));
      sleep_ms(300);
   }
   //turn off led
   for (i = 0; i < 8; i++) {
      sseg_p->write_1ptn(0xff, i);
   }
   //turn off all decimal points
   sseg_p->set_dp(0x00);

}
/*
void get_frequency(MicCore *mic_p, int freq = 2) {
	freq = mic_p->read();
	uart.disp(freq);
	uart.disp("test1\n\r");
}*/

const double LOG_SEMITONE = log(2.0)/12.0;

int getSemitones(double f)
{
	//double note = log(f/440.0) / LOG_SEMITONE;
	double note = log(f/16.35) / LOG_SEMITONE;
    return (int)round(note);
}
/*
char getNote(int semitones) {
	int note;
	int accidental = 255;
	int octave;
	int noteArray[12] = {198,161,161,134,134,142,194,194,136,136,131,131};

	octave = semitones / 12;
	note = semitones % 12;

	sseg_p->write_1ptn(noteArray[note], 3);

	if(note == 1 || note == 3 || note == 6 || note == 8 || note = 10) {
		accidental = 131;
	}

	sseg_p->write_1ptn(accidental, 2);
	sseg_p->write_1ptn(octave, 3);

}
*/
unsigned concatenate(unsigned x, unsigned y) {
    unsigned pow = 10;
    while(y >= pow)
        pow *= 10;
    return x * pow + y;
}

void determineNote(Ps2Core *ps2_p, SsegCore *sseg_p) {
//	int id;
	char key_input;
	//char input_freq[7] = {'0','4','4','0','.','0','0'};
	//char input_freq[7] = {'0','4','6','6','.','1','6'};
	//char input_freq[7] = {'0','3','9','2','.','0','0'};
	char input_freq[7] = {'0','2','6','1','.','6','3'};
	int i = 0;
	int char2Num;
	double freq = 0;
	int semitones = 0;

    ps2_p->init();

	uart.disp("\r\nEnter frequency: ");
	do { // get keyboard input
		if(ps2_p->get_kb_ch(&key_input)) {
			//uart.disp("After get_kb_ch\n\r");
			uart.disp(key_input);
			input_freq[i] = key_input;
			i++;
		} /*else {
			//uart.disp("Not detected\r\n");
			i++;
		}*/
		//sleep_ms(10);
	} while (i < 7);
	//uart.disp("\r\nExiting loop");
	//sleep_ms(10);

	for(i = 0; i < 7; i++) {
		//uart.disp("Entering loop\r\n");
		if(input_freq[i] != '.') {
			//uart.disp("Entering if\r\n");
			char2Num = input_freq[i] - '0';
			//uart.disp(char2Num); uart.disp("\r\n");
			freq = concatenate(freq,char2Num);
			//uart.disp(freq); uart.disp("\r\n");
		}
	}
	//uart.disp("Exiting loop\r\n");
	//sleep_ms(10);

	freq = freq / 100;
	//uart.disp(" = "); uart.disp(freq); uart.disp("\r\n");

	semitones = getSemitones(freq);
	//uart.disp(semitones);
	//uart.disp("\r\n");

	int note;
	int accidental = 255;
	int octave;
	//int noteArray[12] = {198,161,161,134,134,142,194,194,136,136,131,131};
	static const uint8_t noteArray[12] =
		{0xc6, 0xa1, 0xa1, 0x86, 0x86, 0x8e, 0xc2, 0xc2, 0x88, 0x88, 0x83, 0x83};

	octave = semitones / 12;
	//uart.disp(octave); uart.disp("\r\n");
	note = semitones % 12;
	//uart.disp(note); uart.disp("\r\n");

	sseg_p->write_1ptn(noteArray[note], 3);
	//uart.disp(noteArray[note]); uart.disp("\r\n");

	if(note == 1 || note == 3 || note == 6 || note == 8 || note == 10) {
		accidental = 131;
	}

	sseg_p->write_1ptn(accidental, 2);
	//uart.disp(accidental); uart.disp("\r\n");
	sseg_p->write_1ptn(sseg_p->h2s(octave), 1);

}

// instantiate cores
GpoCore led(get_slot_addr(BRIDGE_BASE, S2_LED));
GpiCore sw(get_slot_addr(BRIDGE_BASE, S3_SW));
PwmCore pwm(get_slot_addr(BRIDGE_BASE, S6_PWM));
SsegCore sseg(get_slot_addr(BRIDGE_BASE, S8_SSEG));
Ps2Core ps2(get_slot_addr(BRIDGE_BASE, S11_PS2));
//MicCore mic(get_slot_addr(BRIDGE_BASE, S4_USER));


int main() {
	/*
	int freq = 493.88;
	int semitones = getNote(freq);
	std::string note = determineNote(semitones);
	char character = note[0];
	uart.disp(character);*/

	while(1) {
		/*get_frequency(&mic, freq);
		uart.disp(freq);
		sleep_ms(500);
		uart.disp("test\n\r");*/
		//sseg_check(&sseg);
		//sleep_ms(100);
		determineNote(&ps2, &sseg);
		sleep_ms(100);
		//sleep_ms(100);
	}

} //main

