/*****************************************************************//**
 * @file mic_core.cpp
 *
 *
 *
 * @author John Westbrook
 ********************************************************************/


#include "mic_core.h"

/*
 * Modified from GpiCore
 *
 */

MicCore::MicCore(uint32_t core_base_addr) {
   base_addr = core_base_addr;
}
MicCore::~MicCore() {
}

uint32_t MicCore::read() {
   return (io_read(base_addr, DATA_REG));
}

int MicCore::read(int bit_pos) {
   uint32_t rd_data = io_read(base_addr, DATA_REG);
   return ((int) bit_read(rd_data, bit_pos));
}


