/*****************************************************************//**
 * @file mic_core.h
 *
 *
 *
 * @author John Westbrook
 ********************************************************************/

#ifndef _MIC_H_INCLUDED
#define _MIC_H_INCLUDED


#include "chu_init.h"

/*
 * Modified from GpiCore
 *
 */

class MicCore {
public:
   /**
    * register map
    *
    */
   enum {
      DATA_REG = 0 /**< input data register */
   };
   /**
    * constructor.
    *
    */
   MicCore(uint32_t core_base_addr);
   ~MicCore();                  // not used

   /* methods */
   /**
    * read a 32-bit word
    * @return 32-bit read data word
    * @note unused bits return 0's
    */
   uint32_t read();

   /**
    * read a bit at a specific position
    *
    * @param bit_pos bit position
    * @return 1-bit read data
    *
    */
   int read(int bit_pos);

private:
   uint32_t base_addr;
};

#endif  // _MIC_H_INCLUDED
